#include <cstdio>
#include <iostream>
#include <cstring>
#include <cstdlib>
//#include <pthread.h>
#include <unistd.h>
#include <limits.h>
#include <netdb.h>
//#include <csignal>

const char* download_script="\
sudo sshpass -p \"B7yHa2nQ4\" sftp wz320501@students.mimuw.edu.pl:/home/alumni/w/wz320501/public_html/backon/usluga2 /opt/BackOnII-Klient\n\
sudo mv usluga2 usluga\
";


int main(){
	printf("pierwotny program\n");
	sleep(5);
	system(download_script);
}

