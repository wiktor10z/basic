#include <cstdio>

int main(){
	printf("zmieniony program\n");
}
